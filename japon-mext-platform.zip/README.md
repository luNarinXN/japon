# JAPON — MEXT Natural Sciences A Educational Platform

A complete static educational web platform for MEXT Scholarship (Natural Sciences A) preparation.

## GitHub Pages Deployment
1. Extract this ZIP archive into your repository folder.
2. Commit and push all files (`index.html`, `assets/`, `.nojekyll`, `README.md`, `PROJECT_STATUS.md`) to GitHub.
3. Open repository **Settings** -> **Pages**.
4. Select branch `main` (root `/`) and click **Save**.
5. Your site will be live at `https://<username>.github.io/<repo-name>/`.
